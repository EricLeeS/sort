package com.leeecode.m1;

public class Main {
	public static void main(String[] args){
		Solution so = new Solution();
		int[] sr={0,4,3,0};
		int target = 0;
		so.twoSum(sr, target);
	}
}
